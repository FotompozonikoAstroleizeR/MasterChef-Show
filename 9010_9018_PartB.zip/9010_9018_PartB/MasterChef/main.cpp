/* ������������������ ���������������*/
//Names: Mavromanolis Antonios, Pliakis Thomas*/
//A.E.M.: 9010, 9018
//emails: antonisira@gmail.com , thpliakis@gmail.com


#include <iostream>
#include <string>
#include "Player.h"
#include "Team.h"
#include "math.h"

using namespace std;

int main()
{
    int a=0;  //��������� ��� ������ ��� �����
    int position=0; //���� �� ������
    int i=-1; //������� ������ �������� ������
    int j=-1;//������� ������ ���� ������
    int c=0; //��������� ��� �������� �����

    bool flag=false;

    string xd;
    string e="";
    string b;

    Player  p("","","",0,0,0,50,(rand() % 81)); //����������� p

    Team red("red",0,0); // ����������� ������� team ��� ��� ������� �����
    Team blue("blue",0,0);  // ����������� ������� team ��� ��� ���� �����


    //�����
    cout <<"Welcome to the Masterchef Show 2018"<<endl;
    cout <<"Press 1 to register new players.\nPress 2 to show informations about a team."<<endl;
    cout <<"Press 3 to show information about a player of a team according to his name."<<endl;
    cout <<"Press 4 to show information about a player of a team according to his number in the team."<<endl;
    cout <<"Press 5 to exit the program."<<endl;

    cin>>a; //������� ��� �� ������������



    while(a!=5)
    {
        if (a==1)
        {
            e="";
            while((e!="exit") && (i<11) && (j<11))
            {
                cout <<"Which team do you want to register a player in? (type red or blue):"<<endl;
                cin >> b;

                if(b=="red")
                {
                    cout <<"Give player's name:"<<endl;
                    cin >> xd ;
                    p.setName(xd);
                    cout <<"Give player's age (0-...):"<<endl;
                    cin >> c;
                    p.setAge(c);
                    cout <<"Give player's job:"<<endl;
                    cin >> xd;
                    p.setJob(xd);
                    cout <<"Give player's sex (male or female or other):"<<endl;
                    cin >> xd;
                    p.setSex(xd);
                    cout <<"Give player's exhaustion (0-100):"<<endl;
                    cin >> c;
                    p.setExhaustion(c);
                    i++;
                    red.setPlayers(p,i);

                }
                else if(b=="blue")
                {
                    cout <<"Give player's name:"<<endl;
                    cin >> xd ;
                    p.setName(xd);
                    cout <<"Give player's age (0-...):"<<endl;
                    cin >> c;
                    p.setAge(c);
                    cout <<"Give player's job:"<<endl;
                    cin >> xd;
                    p.setJob(xd);
                    cout <<"Give player's sex (male or female or other):"<<endl;
                    cin >> xd;
                    p.setSex(xd);
                    cout <<"Give player's exhaustion (0-100):"<<endl;
                    cin >> c;
                    p.setExhaustion(c);
                    j++;
                    blue.setPlayers(p,j);

                }
                else
                {
                    cout<<"Give a valid answer."<<endl;
                }
                cout <<"Type exit to exit registering or anything else to continue"<<endl;
                cin >> e;
                cout<<endl;
            }
        }
        else if (a==2)
        {
            e="";
            while(e!="exit")
            {
                cout <<"Which team's information do you want to learn about? (type red or blue)"<<endl;
                cin >> b;
                if(b=="red")
                {
                    if(i==-1)
                    {
                        cout<<"\nTeam Red has 0 members"<<endl;
                        break;
                    }
                    cout <<"\nTeam's name: Red"<<endl;
                    cout <<"Number of team's players: "<<(i+1)<<endl;
                    cout <<"Team's wins: "<<red.getWins()<<endl;
                    cout <<"Team's players names:"<<endl;
                    for(int k=0;k<=i;k++)
                    {
                        p=red.getPlayers(k);
                        cout <<(k+1)<<") "<<p.getName()<<endl<<endl;
                    }
                }
                else if(b=="blue")
                {
                    if(j==-1)
                    {
                        cout<<"\nTeam Blue has 0 members"<<endl;
                        break;
                    }
                    cout <<"\nTeam's name: Blue"<<endl;
                    cout <<"Number of team's players: "<<(j+1)<<endl;
                    cout <<"Team's wins: "<<blue.getWins()<<endl;
                    cout <<"Team's players names:"<<endl;
                    for(int k=0;k<=j;k++)
                    {
                        p=blue.getPlayers(k);
                        cout <<(k+1)<<") "<<p.getName()<<endl<<endl;
                    }
                }
                else
                {
                        cout<<"Give a valid answer."<<endl;
                }
                cout <<"Type exit to exit or anything else to continue"<<endl;
                cin >> e;
                cout<<endl;
                }
        }
        else if (a==3)
        {
            e="";
            position=0;

            flag=false;

            while(e!="exit")
            {

                cout<<"Give player's name"<<endl;
                cin >> xd;
                for(int k=0;k<=i;k++)
                {

                    if(red.getPlayers(k).getName()==xd)
                    {
                        b="red";
                        flag=false;
                        position=k;
                        break;
                    }
                    else
                    {
                        flag= true;
                    }
                }
                if(b!="red")
                {
                    for(int k=0;k<=j;k++)
                    {

                        if(blue.getPlayers(k).getName()==xd)
                        {
                            b="blue";
                            flag=false;
                            position=k;
                            break;
                        }
                        else
                        {
                           flag= true;
                        }
                    }
                }
                if (flag==true)
                {
                    cout<<"No such player found."<<endl;
                    break;
                }
                if(b=="red")
                {
                    cout <<"Players Team: red\n";
                    cout <<"Player's name: " <<red.getPlayers(position).getName() <<endl;
                    cout <<"Player's age: " << red.getPlayers(position).getAge() <<endl;
                    cout <<"Player's job: " << red.getPlayers(position).getJob() <<endl;
                    cout <<"Player's sex: " << red.getPlayers(position).getSex() <<endl;
                    cout <<"Player's exhaustion: " << red.getPlayers(position).getExhaustion() <<endl;
                    cout <<"Player's wins: " <<red.getPlayers(position).getWins() <<endl;
                    cout <<"Player's popularity: " <<red.getPlayers(position).getPopularity() <<endl;
                    cout <<"Player's technical experience: " <<red.getPlayers(position).getTechnicalExperience() <<endl;
                }
                else if(b=="blue")
                {
                    cout <<"Players Team: blue\n";
                    cout <<"Player's name: " <<blue.getPlayers(position).getName() <<endl;
                    cout <<"Player's age: " << blue.getPlayers(position).getAge() <<endl;
                    cout <<"Player's job: " << blue.getPlayers(position).getJob() <<endl;
                    cout <<"Player's sex: " << blue.getPlayers(position).getSex() <<endl;
                    cout <<"Player's exhaustion: " << blue.getPlayers(position).getExhaustion() <<endl;
                    cout <<"Player's wins: " <<blue.getPlayers(position).getWins() <<endl;
                    cout <<"Player's popularity: " <<blue.getPlayers(position).getPopularity() <<endl;
                    cout <<"Player's technical experience: " <<blue.getPlayers(position).getTechnicalExperience() <<endl<<endl;
                }
                else
                {
                    cout<<"No such player found."<<endl<<endl;
                    if(i==-1)
                    {
                        cout<<"\nTeam Red has 0 members."<<endl;
                    }
                    if(j==-1)
                    {
                        cout<<"\nTeam Blue has 0 members."<<endl;
                    }
                }
                cout <<"Type exit to exit or anything else to continue."<<endl;
                cin >> e;
                cout<<endl;
            }
        }
        else if (a==4)
        {
            e="";
            while(e!="exit")
            {
                cout <<"From which team do you want to learn a player's information about? (type red or blue):"<<endl;
                cin >> b;
                if(b=="red")
                {
                    if(i==-1)
                    {
                        cout<<"\nTeam Red has 0 members."<<endl;
                        break;
                    }


                    cout <<"Team's Red players names:"<<endl;
                    for(int k=0;k<=i;k++)
                    {

                        cout <<(k+1)<<") "<<red.getPlayers(k).getName()<<endl;
                    }
                    cout <<"Give player's number:"<<endl;
                    cin >> c ;

                    while(c>i+1)
                    {
                        cout<<"There are not so many players in the red team.";
                        cout<<"\nGive a new number:\n";
                        cin >> c;
                    }
                        cout <<"Player's name: " <<red.getPlayers(c-1).getName() <<endl;
                        cout <<"Player's age: " << red.getPlayers(c-1).getAge() <<endl;
                        cout <<"Player's job: " << red.getPlayers(c-1).getJob() <<endl;
                        cout <<"Player's sex: " << red.getPlayers(c-1).getSex() <<endl;
                        cout <<"Player's exhaustion: " << red.getPlayers(c-1).getExhaustion() <<endl;
                        cout <<"Player's wins: " <<red.getPlayers(c-1).getWins() <<endl;
                        cout <<"Player's popularity: " <<red.getPlayers(c-1).getPopularity() <<endl;
                        cout <<"Player's technical experience: " <<red.getPlayers(c-1).getTechnicalExperience() <<endl;


                }
                else if(b=="blue")
                {
                    if(j==-1)
                    {
                        cout<<"\nTeam Blue has 0 members"<<endl;
                        break;
                    }
                    cout <<"Team's Blue players names:"<<endl;
                    for(int k=0;k<=j;k++)
                    {

                        cout <<(k+1)<<") "<<blue.getPlayers(k).getName()<<endl;
                    }
                    cout <<"Give player's number"<<endl;
                    cin >> c ;

                    while(c>j+1)
                    {
                        cout<<"There are not so many players in the red team.";
                        cout<<"\nGive a new number:\n";
                        cin >> c;
                    }

                    cout <<"Player's name: " <<blue.getPlayers(c-1).getName() <<endl;
                    cout <<"Player's age: " << blue.getPlayers(c-1).getAge() <<endl;
                    cout <<"Player's job: " << blue.getPlayers(c-1).getJob() <<endl;
                    cout <<"Player's sex: " << blue.getPlayers(c-1).getSex() <<endl;
                    cout <<"Player's exhaustion: " << blue.getPlayers(c-1).getExhaustion() <<endl;
                    cout <<"Player's wins: " <<blue.getPlayers(c-1).getWins() <<endl;
                    cout <<"Player's popularity: " <<blue.getPlayers(c-1).getPopularity() <<endl;
                    cout <<"Player's technical experience: " <<blue.getPlayers(c-1).getTechnicalExperience() <<endl;


                }
                else
                {
                    cout<<"Give a valid answer."<<endl;
                }
                cout <<"Type exit to exit showing information or anything else to continue"<<endl;
                cin >> e;
                cout<<endl;
            }
        }
        else if (a==5)
        {
            break;
        }
        else
        {
            cout<< "Select one of the options above. Please try again."<<endl;
        }

        cout <<"*************************************************************************************"<<endl;
        cout <<"Welcome to the Masterchef Show 2018"<<endl;
        cout <<"Press 1 to register new players.\nPress 2 to show informations about a team."<<endl;
        cout <<"Press 3 to show information about a player of a team according to his name."<<endl;
        cout <<"Press 4 to show information about a player of a team according to his number in the team."<<endl;
        cout <<"Press 5 to exit the program."<<endl;
        cin>>a;

    }

    cout <<"*************************************************************************************"<<endl;
    cout<<"THE END!!!!"<<endl;

}
